const express = require('express');
const axios = require('axios');
const cors = require('cors');
const { Client, GatewayIntentBits } = require('discord.js');
require('dotenv').config();

const app = express();
const port = 3000;

app.use(cors()); // Allow frontend to communicate with backend
app.use(express.json()); // Parse JSON bodies

// Discord bot setup
const bot = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

bot.login(process.env.BOT_TOKEN).catch(err => {
  console.error('Bot login failed:', err.message);
});

bot.on('ready', () => {
  console.log(`Bot logged in as ${bot.user.tag}`);
});

bot.on('error', (error) => {
  console.error('Bot error:', error.message);
});

// Store webhooks (in a real app, use a database)
let webhooks = [];

// Middleware to log all requests
app.use((req, res, next) => {
  console.log(`[${new Date().toLocaleTimeString()}] ${req.method} ${req.url}`);
  next();
});

// Endpoint to add a webhook
app.post('/add-webhook', async (req, res) => {
  console.log('Processing /add-webhook request:', req.body);
  const { url } = req.body;
  if (!url || !url.startsWith('https://discord.com/api/webhooks/')) {
    console.log('Invalid webhook URL:', url);
    return res.status(400).json({ error: 'Invalid webhook URL' });
  }

  try {
    const response = await axios.get(url);
    const webhookData = response.data;
    if (!webhookData.channel_id || !webhookData.id) {
      console.log('Invalid webhook data:', webhookData);
      return res.status(400).json({ error: 'Invalid webhook data' });
    }

    const webhook = {
      url,
      id: webhookData.id,
      name: webhookData.name || 'Unnamed Webhook',
      avatar: webhookData.avatar
        ? `https://cdn.discordapp.com/avatars/${webhookData.id}/${webhookData.avatar}.png`
        : 'https://cdn.discordapp.com/embed/avatars/0.png',
      channelId: webhookData.channel_id
    };

    webhooks.push(webhook);
    console.log('Webhook added:', webhook);
    res.status(200).json(webhook);
  } catch (error) {
    console.error('Error adding webhook:', error.message);
    res.status(500).json({ error: 'Failed to add webhook', details: error.message });
  }
});

// Endpoint to get all webhooks
app.get('/webhooks', (req, res) => {
  console.log('Processing /webhooks request');
  res.status(200).json(webhooks);
});

// Endpoint to delete a webhook
app.delete('/webhook/:id', (req, res) => {
  console.log('Processing /webhook/:id delete request for ID:', req.params.id);
  const { id } = req.params;
  webhooks = webhooks.filter(w => w.id !== id);
  console.log('Webhook deleted, remaining webhooks:', webhooks.length);
  res.status(200).json({ message: 'Webhook deleted' });
});

// Endpoint to send a message
app.post('/send-message', async (req, res) => {
  console.log('Processing /send-message request:', req.body);
  const { webhookId, content } = req.body;
  if (!webhookId || !content) {
    console.log('Missing webhookId or content:', req.body);
    return res.status(400).json({ error: 'Webhook ID and content are required' });
  }

  const webhook = webhooks.find(w => w.id === webhookId);
  if (!webhook) {
    console.log('Webhook not found for ID:', webhookId);
    return res.status(404).json({ error: 'Webhook not found' });
  }

  try {
    await axios.post(webhook.url, { content });
    console.log('Message sent successfully to webhook:', webhookId);
    res.status(200).json({ message: 'Message sent successfully' });
  } catch (error) {
    console.error('Error sending message:', error.message);
    res.status(500).json({ error: 'Failed to send message', details: discord.js });
  }
});

// Endpoint to fetch messages
app.get('/messages/:channelId', async (req, res) => {
  const { channelId } = req.params;
  console.log(`Processing /messages/${channelId} request`);
  try {
    if (!bot.isReady()) {
      console.log('Bot is not ready yet');
      return res.status(503).json({ error: 'Bot is not ready' });
    }

    const channel = await bot.channels.fetch(channelId);
    if (!channel) {
      console.log(`Channel not found: ${channelId}`);
      return res.status(404).json({ error: 'Channel not found' });
    }

    const messages = await channel.messages.fetch({ limit: 50 });
    console.log(`Fetched ${messages.size} messages from channel: ${channelId}`);
    const messageArray = messages.map(msg => ({
      id: msg.id,
      content: msg.content,
      author: {
        id: msg.author.id,
        username: msg.author.username,
        avatar: msg.author.avatar
          ? `https://cdn.discordapp.com/avatars/${msg.author.id}/${msg.author.avatar}.png`
          : 'https://cdn.discordapp.com/embed/avatars/0.png'
      },
      timestamp: msg.createdTimestamp,
      embeds: msg.embeds.map(embed => ({
        title: embed.title || '',
        description: embed.description || '',
        url: embed.url || '',
        color: embed.color || null,
        fields: embed.fields.map(field => ({
          name: field.name,
          value: field.value,
          inline: field.inline
        })),
        thumbnail: embed.thumbnail ? { url: embed.thumbnail.url } : null,
        image: embed.image ? { url: embed.image.url } : null
      })),
      attachments: msg.attachments.map(attachment => ({
        id: attachment.id,
        filename: attachment.name,
        url: attachment.url,
        contentType: attachment.contentType || 'application/octet-stream'
      }))
    }));

    res.status(200).json(messageArray);
  } catch (error) {
    console.error(`Error fetching messages for channel ${channelId}: ${error.message}`);
    res.status(500).json({ error: 'Failed to fetch messages', details: error.message });
  }
});

app.listen(port, () => {
  console.log(`Backend server running on http://localhost:${port}`);
});